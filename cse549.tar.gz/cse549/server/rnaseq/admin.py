from django.contrib import admin
from models import *


'''
class SailfishDataAdmin(admin.ModelAdmin):
    list_display = ["entry_id", "attribute", "value"]


class KallistoDataAdmin(admin.ModelAdmin):
    list_display = ["entry_id", "attribute", "value"]


class RsemDataAdmin(admin.ModelAdmin):
    list_display = ["entry_id", "attribute", "value"]


admin.site.register(SailfishData, SailfishDataAdmin)
admin.site.register(KallistoData, KallistoDataAdmin)
admin.site.register(RsemData, RsemDataAdmin)
'''
